import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //String s1 = "Hello World!";
        //String s2 = "Hello World!!!";
        Scanner s = new Scanner(System.in);
        System.out.print("String s1: ");
        String s1 = s.nextLine();
        System.out.print("String s2: ");
        String s2 = s.nextLine();
        //System.out.println(s1.equals(s2));
        boolean fl = s1.equals(s2);
        if (fl) {
            System.out.println("Строки идентичны");
        } else {
            System.out.println("Строки неидентичны");
        }
    }
}